using System;
public sealed class Singleton
{
    private static Singleton _instance;

    private static readonly object _lock = new object();

    private Singleton()
    {
        Console.WriteLine("Singleton initialized.");
    }

    public static Singleton GetInstance()
    {
        if (_instance == null)
        {
            lock (_lock)
            {
                if (_instance == null)
                {
                    _instance = new Singleton();
                }
            }
        }
        return _instance;
    }

    public void DoBusinessLogic()
    {
        Console.WriteLine("Executing business logic on the Singleton instance...");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("--- Attempting to create multiple instances ---");

        Singleton instance1 = Singleton.GetInstance();
        Singleton instance2 = Singleton.GetInstance();

        if (ReferenceEquals(instance1, instance2))
        {
            Console.WriteLine("Success: Both variables contain the exact same memory instance.");
        }
        else
        {
            Console.WriteLine("Failure: Instances are different.");
        }

        instance1.DoBusinessLogic();
    }
}
