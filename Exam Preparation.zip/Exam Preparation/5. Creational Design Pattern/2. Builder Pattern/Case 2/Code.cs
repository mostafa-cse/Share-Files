using System;

public class Product1
{
    public void AddFeature(string feature) => Console.WriteLine($"Product1: Added {feature}");
}

public class Product2
{
    public void SetFeatureB() => Console.WriteLine($"Product2: Feature B set.");
}
public interface IBuilder
{
    void Reset();
    void BuildStepA();
    void BuildStepB();
    void BuildStepZ();
}
public class ConcreteBuilder1 : IBuilder
{
    private Product1 _result;

    public ConcreteBuilder1()
    {
        this.Reset();
    }

    public void Reset()
    {
        _result = new Product1();
    }

    public void BuildStepA() => _result.AddFeature("Step A Feature");
    public void BuildStepB() => _result.AddFeature("Step B Feature");
    public void BuildStepZ() => _result.AddFeature("Step Z Feature");

    public Product1 GetResult()
    {
        return _result;
    }
}
public class ConcreteBuilder2 : IBuilder
{
    private Product2 _result;

    public ConcreteBuilder2()
    {
        this.Reset();
    }

    public void Reset()
    {
        _result = new Product2();
    }

    public void BuildStepA() { Console.WriteLine("ConcreteBuilder2: Step A executed."); }
    public void BuildStepB() { Console.WriteLine("ConcreteBuilder2: Step B executed."); }
    
    public void BuildStepZ()
    {
        _result.SetFeatureB();
    }
    public Product2 GetResult()
    {
        return this._result;
    }
}

public class Director
{
    private IBuilder _builder;

    public Director(IBuilder builder)
    {
        _builder = builder;
    }

    public void ChangeBuilder(IBuilder builder)
    {
        _builder = builder;
    }

    public void Make(string type)
    {
        _builder.Reset();
        
        if (type == "simple")
        {
            _builder.BuildStepA();
        }
        else
        {
            _builder.BuildStepB();
            _builder.BuildStepZ();
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Client executing Note 5 ---");
        
        ConcreteBuilder1 b = new ConcreteBuilder1();
        Director d = new Director(b);
        d.Make("simple");
        Product1 p = b.GetResult();
        
        
        Console.WriteLine("\n--- Showing ConcreteBuilder2 (Complex Type) ---");
        ConcreteBuilder2 b2 = new ConcreteBuilder2();
        d.ChangeBuilder(b2);
        d.Make("complex");
        Product2 p2 = b2.GetResult();
    }
}