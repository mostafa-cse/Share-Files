using System;
public class Engine { }
public class SportEngine : Engine { }
public class SUVEngine : Engine { }


public class Car
{
    public int Seats { get; set; }
    public Engine Engine { get; set; }
    public bool HasTripComputer { get; set; }
    public bool HasGPS { get; set; }

    public void ShowSpecs()
    {
        Console.WriteLine($"Car Specs -> Seats: {Seats}, Engine: {Engine.GetType().Name}, TripComputer: {HasTripComputer}, GPS: {HasGPS}");
    }
}

public class Manual
{
    private string _instructions = "";

    public void AddInstruction(string text)
    {
        _instructions += text + "\n";
    }

    public void Print()
    {
        Console.WriteLine("--- Car Manual ---");
        Console.WriteLine(_instructions);
    }
}


// ── 1. Builder Interface ──────────────────────────────────────────
public interface IBuilder
{
    void Reset();
    void SetSeats(int number);
    void SetEngine(Engine engine);
    void SetTripComputer();
    void SetGPS();
}


// ── 2. Concrete Builders ──────────────────────────────────────────
public class CarBuilder : IBuilder
{
    private Car _car;

    public CarBuilder()
    {
        this.Reset();
    }

    public void Reset()
    {
        _car = new Car();
    }

    public void SetSeats(int number) => _car.Seats = number;
    public void SetEngine(Engine engine) => _car.Engine = engine;
    public void SetTripComputer() => _car.HasTripComputer = true;
    public void SetGPS() => _car.HasGPS = true;

    public Car GetResult()
    {
        Car result = _car;
        this.Reset(); 
        return result;
    }
}

public class CarManualBuilder : IBuilder
{
    private Manual _manual;

    public CarManualBuilder()
    {
        this.Reset();
    }

    public void Reset()
    {
        this._manual = new Manual();
    }

    public void SetSeats(int number)
    {
        _manual.AddInstruction($"Documenting seat configuration: {number} seats.");
    }

    public void SetEngine(Engine engine)
    {
        _manual.AddInstruction($"Adding engine instructions for: {engine.GetType().Name}.");
    }

    public void SetTripComputer()
    {
        _manual.AddInstruction("Add a trip computer instruction.");
    }

    public void SetGPS()
    {
        _manual.AddInstruction("Adding GPS navigation instructions.");
    }

    public Manual GetResult()
    {
        Manual result = this._manual;
        this.Reset();
        return result;
    }
}

public class Director
{
    IBuilder builder;
    Director(IBuilder builder)
    {
        this.builder = builder;
    }
    public void MakeSportsCar()
    {
        this.builder.Reset();
        this.builder.SetSeats(2);
        this.builder.SetEngine(new SportEngine());
        this.builder.SetTripComputer();
        this.builder.SetGPS();
    }

    public void MakeSUV()
    {
        this.builder.Reset();
        this.builder.SetSeats(5);
        this.builder.SetEngine(new SUVEngine());
        this.builder.SetTripComputer();
        this.builder.SetGPS();
    }
}

class Program
{
    static void Main(string[] args)
    {
        CarBuilder builder = new CarBuilder();
        Director director = new Director(builder);
        
        director.MakeSportsCar();
        Car car = builder.GetResult();
        Console.WriteLine("--- Physical Car Output ---");
        car.ShowSpecs();

        Console.WriteLine("\n--- Manual Output ---");
        CarManualBuilder manualBuilder = new CarManualBuilder();
        Director director = new Director(manualBuilder);
        
        director.MakeSportsCar();
        Manual manual = manualBuilder.GetResult();

        CarBuilder builder = new CarBuilder();
        builder.SetEngine(new SUVEngine())
            .SetSeats(5)
            .SetTripComputer()
            .SetGPS();

        manual.Print();
    }
}