using System;
using System.Collections.Generic;

// ── 1. Product ────────────────────────────────────────────────────
public class Pizza
{
    private List<string> _ingredients = new List<string>();

    public void Add(string ingredient)
    {
        _ingredients.Add(ingredient);
    }

    public void Serve()
    {
        Console.WriteLine($"Pizza ready with: {string.Join(", ", _ingredients)}");
    }
}

// ── 2. Builder Interface ──────────────────────────────────────────
public interface IPizzaBuilder
{
    void Reset();
    void BuildDough();
    void BuildSauce();
    void BuildCheese();
    void BuildToppings();
}

// ── 3. Concrete Builders ──────────────────────────────────────────
public class MargheritaBuilder : IPizzaBuilder
{
    private Pizza _pizza = new Pizza();

    public MargheritaBuilder() { this.Reset(); }
    public void Reset() => _pizza = new Pizza();

    public void BuildDough() => _pizza.Add("Thin Neapolitan Crust");
    public void BuildSauce() => _pizza.Add("San Marzano Tomato Sauce");
    public void BuildCheese() => _pizza.Add("Fresh Mozzarella");
    public void BuildToppings() => _pizza.Add("Fresh Basil Leaves");

    public Pizza GetResult()
    {
        Pizza result = _pizza;
        this.Reset();
        return result;
    }
}

public class CustomPizzaBuilder : IPizzaBuilder
{
    private Pizza _pizza = new Pizza();

    public CustomPizzaBuilder() { this.Reset(); }
    public void Reset() => _pizza = new Pizza();

    public void BuildDough() => _pizza.Add("Standard Hand-Tossed Crust");
    public void BuildSauce() => _pizza.Add("Classic Marinara");
    public void BuildCheese() => _pizza.Add("Shredded Mozzarella");
    public void BuildToppings() { /* Left blank on purpose for custom additions */ }
    public void AddSpecificIngredient(string ingredient)
    {
        _pizza.Add(ingredient);
    }

    public Pizza GetResult()
    {
        Pizza result = _pizza;
        this.Reset();
        return result;
    }
}

// ── 4. Director ───────────────────────────────────────────────────
public class ChefDirector
{
    public void MakeClassicPizza(IPizzaBuilder builder)
    {
        builder.Reset();
        builder.BuildDough();
        builder.BuildSauce();
        builder.BuildCheese();
        builder.BuildToppings();
    }

    public void MakePlainCheesePizza(IPizzaBuilder builder)
    {
        builder.Reset();
        builder.BuildDough();
        builder.BuildSauce();
        builder.BuildCheese();
    }
}

// ── 5. Client ─────────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        ChefDirector chef = new ChefDirector();

        Console.WriteLine("--- Ordering a Classic Margherita ---");
        MargheritaBuilder margheritaBuilder = new MargheritaBuilder();
        chef.MakeClassicPizza(margheritaBuilder);
        Pizza margherita = margheritaBuilder.GetResult();
        margherita.Serve();

        Console.WriteLine("\n--- Ordering a Plain Cheese Pizza ---");
        CustomPizzaBuilder baseBuilder = new CustomPizzaBuilder();
        chef.MakePlainCheesePizza(baseBuilder);
        Pizza plainCheese = baseBuilder.GetResult();
        plainCheese.Serve();

        // -------------------------------------------------------------
        // NO DIRECTOR NEEDED: The client can act as the director to
        // construct a highly customized product step-by-step!
        // -------------------------------------------------------------
        Console.WriteLine("\n--- Building a Completely Custom Pizza ---");
        CustomPizzaBuilder customBuilder = new CustomPizzaBuilder();
        customBuilder.BuildDough();
        customBuilder.BuildSauce();
        customBuilder.BuildCheese();
        
        // Adding custom ingredients using our specialized method
        customBuilder.AddSpecificIngredient("Pepperoni");
        customBuilder.AddSpecificIngredient("Mushrooms");
        customBuilder.AddSpecificIngredient("Extra Jalapenos");
        
        Pizza customPizza = customBuilder.GetResult();
        customPizza.Serve();
    }
}