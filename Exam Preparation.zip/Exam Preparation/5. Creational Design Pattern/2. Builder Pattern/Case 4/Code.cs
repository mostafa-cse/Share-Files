using System;
using System.Collections.Generic;

// ── 1. Product ────────────────────────────────────────────────────
public class Pizza
{
    private List<string> _ingredients = new List<string>();

    public void Add(string ingredient)
    {
        _ingredients.Add(ingredient);
    }

    public void Serve()
    {
        Console.WriteLine($"Pizza ready with: {string.Join(", ", _ingredients)}");
    }
}

// ── 2. Fluent Builder ─────────────────────────────────────────────
public class FluentPizzaBuilder
{
    private Pizza _pizza = new Pizza();

    public FluentPizzaBuilder()
    {
        this.Reset();
    }

    // Returns 'this' to allow method chaining
    public FluentPizzaBuilder Reset()
    {
        _pizza = new Pizza();
        return this;
    }

    public FluentPizzaBuilder WithDough(string doughType)
    {
        _pizza.Add(doughType);
        return this; // <--- The magic of the fluent pattern!
    }

    public FluentPizzaBuilder WithSauce(string sauceType)
    {
        _pizza.Add(sauceType);
        return this;
    }

    public FluentPizzaBuilder WithCheese(string cheeseType)
    {
        _pizza.Add(cheeseType);
        return this;
    }

    public FluentPizzaBuilder AddTopping(string topping)
    {
        _pizza.Add(topping);
        return this;
    }

    // The final method returns the actual Product, not the Builder
    public Pizza Build()
    {
        Pizza result = _pizza;
        this.Reset(); // Prepare for the next potential build
        return result;
    }
}

// ── 3. Client ─────────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        FluentPizzaBuilder builder = new FluentPizzaBuilder();

        Console.WriteLine("--- Ordering via Fluent Interface ---");
        
        // Look at how beautifully this reads! 
        // It reads almost exactly like natural English.
        Pizza myPizza = builder
            .WithDough("Garlic Herb Crust")
            .WithSauce("Spicy Marinara")
            .WithCheese("Smoked Gouda")
            .AddTopping("Pepperoni")
            .AddTopping("Black Olives")
            .AddTopping("Onions")
            .Build(); 

        myPizza.Serve();
    }
}