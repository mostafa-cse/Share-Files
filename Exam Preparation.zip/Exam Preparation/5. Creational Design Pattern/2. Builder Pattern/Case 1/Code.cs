using System;
using System.Collections.Generic;


public class House
{
    private List<string> _parts = new List<string>();

    public void Add(string part)
    {
        _parts.Add(part);
    }

    public string ListParts()
    {
        return string.Join(", ", _parts);
    }
}
public interface IHouseBuilder
{
    void Reset();
    void BuildWalls(int count);
    void BuildDoors(int count);
    void BuildWindows(int count);
    void BuildRoof();
    void BuildGarage();
    void BuildSwimmingPool();
}

public class WoodHouseBuilder : IHouseBuilder
{
    private House _house = new House();

    public WoodHouseBuilder()
    {
        this.Reset();
    }

    public void Reset()
    {
        _house = new House();
    }

    public void BuildWalls(int count) => _house.Add($"{count} Wooden Walls");
    public void BuildDoors(int count) => _house.Add($"{count} Wooden Door(s)");
    public void BuildWindows(int count) => _house.Add($"{count} Basic Windows");
    public void BuildRoof() => _house.Add("Shingle Roof");
    public void BuildGarage() => _house.Add("Wooden Carport");
    public void BuildSwimmingPool() => _house.Add("Above-ground Pool");
    public House GetResult()
    {
        House result = _house;
        this.Reset(); 
        return result;
    }
}

public class StoneCastleBuilder : IHouseBuilder
{
    private House _castle = new House();

    public StoneCastleBuilder()
    {
        this.Reset();
    }

    public void Reset()
    {
        _castle = new House();
    }

    public void BuildWalls(int count) => _castle.Add($"{count} Massive Stone Walls");
    public void BuildDoors(int count) => _castle.Add($"{count} Iron Portcullis");
    public void BuildWindows(int count) => _castle.Add($"{count} Arrow Slit Windows");
    public void BuildRoof() => _castle.Add("Stone Battlements");
    public void BuildGarage() => _castle.Add("Horse Stable");
    public void BuildSwimmingPool() => _castle.Add("Defensive Moat");

    public House GetResult()
    {
        House result = _castle;
        this.Reset();
        return result;
    }
}

public class Director
{
    private IHouseBuilder _builder;

    public IHouseBuilder Builder
    {
        set { _builder = value; }
    }
    public void ConstructBasicHouse()
    {
        _builder.BuildWalls(4);
        _builder.BuildDoors(1);
        _builder.BuildWindows(2);
        _builder.BuildRoof();
    }
    public void ConstructLuxuryHouse()
    {
        _builder.BuildWalls(8);
        _builder.BuildDoors(2);
        _builder.BuildWindows(10);
        _builder.BuildRoof();
        _builder.BuildGarage();
        _builder.BuildSwimmingPool();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Director director = new Director();
        
        Console.WriteLine("--- Building a Basic Log Cabin ---");
        WoodHouseBuilder woodBuilder = new WoodHouseBuilder();
        director.Builder = woodBuilder;
        director.ConstructBasicHouse();
        Console.WriteLine($"House features: {woodBuilder.GetResult().ListParts()}");

        Console.WriteLine("\n--- Building a Luxury Castle ---");
        StoneCastleBuilder stoneBuilder = new StoneCastleBuilder();
        director.Builder = stoneBuilder;
        director.ConstructLuxuryHouse();
        Console.WriteLine($"Castle features: {stoneBuilder.GetResult().ListParts()}");

        Console.WriteLine("\n--- Building a Custom House (No Director) ---");
        WoodHouseBuilder customBuilder = new WoodHouseBuilder();
        customBuilder.BuildWalls(6)
                     .BuildDoors(1)
                     .BuildGarage();
        Console.WriteLine($"Custom House features: {customBuilder.GetResult().ListParts()}");
    }
}