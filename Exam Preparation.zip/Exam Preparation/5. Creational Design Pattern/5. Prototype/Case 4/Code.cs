using System;
using System.Collections.Generic;

// ── 1. Abstract Prototype ─────────────────────────────────────────
// Italicized in UML, meaning it is an abstract class.
public abstract class Shape
{
    private int _x;
    private int _y;
    private string _color;

    // Standard constructor
    public Shape(int x, int y, string color)
    {
        _x = x;
        _y = y;
        _color = color;
    }

    // Copy Constructor - Copies fields from the source object
    public Shape(Shape source)
    {
        if (source != null)
        {
            this._x = source._x;
            this._y = source._y;
            this._color = source._color;
        }
    }

    // Abstract clone method to be implemented by subclasses
    public abstract Shape Clone();

    public virtual void DisplayInfo()
    {
        Console.Write($"Position: ({_x}, {_y}), Color: {_color}");
    }
}

// ── 2. Concrete Prototypes ────────────────────────────────────────
public class Rectangle : Shape
{
    private int _width;
    private int _height;

    // Standard constructor
    public Rectangle(int x, int y, string color, int width, int height) 
        : base(x, y, color)
    {
        _width = width;
        _height = height;
    }

    // Copy Constructor - calls base(source) to handle x, y, and color
    public Rectangle(Rectangle source) : base(source)
    {
        if (source != null)
        {
            this._width = source._width;
            this._height = source._height;
        }
    }

    // Cloning itself using its own copy constructor
    public override Shape Clone()
    {
        return new Rectangle(this);
    }

    public override void DisplayInfo()
    {
        Console.Write("[Rectangle] ");
        base.DisplayInfo();
        Console.WriteLine($", Width: {_width}, Height: {_height}");
    }
}

public class Circle : Shape
{
    private int _radius;

    // Standard constructor
    public Circle(int x, int y, string color, int radius) 
        : base(x, y, color)
    {
        _radius = radius;
    }

    // Copy Constructor
    public Circle(Circle source) : base(source)
    {
        if (source != null)
        {
            this._radius = source._radius;
        }
    }

    public override Shape Clone()
    {
        return new Circle(this);
    }

    public override void DisplayInfo()
    {
        Console.Write("[Circle] ");
        base.DisplayInfo();
        Console.WriteLine($", Radius: {_radius}");
    }
}

// ── 3. Client / Aggregator ────────────────────────────────────────
// Holds an aggregation of Shape objects and clones them.
public class Application
{
    private List<Shape> _shapes = new List<Shape>();

    public Application()
    {
        // Populate the initial array of shapes
        Circle circle = new Circle(10, 10, "Red", 15);
        _shapes.Add(circle);

        Rectangle rectangle = new Rectangle(20, 30, "Blue", 40, 50);
        _shapes.Add(rectangle);
    }

    public void BusinessLogic()
    {
        List<Shape> shapesCopy = new List<Shape>();

        Console.WriteLine("--- Original Shapes ---");
        foreach (Shape s in _shapes)
        {
            s.DisplayInfo();
            // Clone the shapes polymorphically!
            shapesCopy.Add(s.Clone());
        }

        Console.WriteLine("\n--- Cloned Shapes ---");
        foreach (Shape copy in shapesCopy)
        {
            copy.DisplayInfo();
        }

        Console.WriteLine("\n--- Verification ---");
        Console.WriteLine($"Is Circle identical in memory? {ReferenceEquals(_shapes[0], shapesCopy[0])}");
    }
}

// ── Entry Point ───────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        Application app = new Application();
        app.BusinessLogic();
    }
}