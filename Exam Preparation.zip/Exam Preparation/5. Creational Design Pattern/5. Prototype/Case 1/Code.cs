using System;
using System.Collections.Generic;

public interface IPrototype
{
    IPrototype Clone();
}
public class Robot : IPrototype
{
    public string Name { get; set; }
    public string Configuration { get; set; }
    
    public Robot(string name, string configuration)
    {
        Name = name;
        Configuration = configuration;
        Console.WriteLine($"[Built from Scratch] Assembling {Name} with {Configuration}...");
    }

    public IPrototype Clone()
    {
        Console.WriteLine($"[Cloning] Splitting/Copying {Name}...");
        return (IPrototype)this.MemberwiseClone();
    }

    public void Speak()
    {
        Console.WriteLine($"  -> \"HELLO, BRO!\" I am {Name} running {Configuration}.");
    }
}

public class RobotRegistry
{
    private Dictionary<string, Robot> _prototypes = new Dictionary<string, Robot>();

    public void RegisterPrototype(string configKey, Robot robot)
    {
        _prototypes[configKey] = robot;
    }

    public Robot CreateClone(string configKey)
    {
        if (_prototypes.TryGetValue(configKey, out Robot prototype))
        {
            return (Robot)prototype.Clone();
        }
        
        throw new ArgumentException("Configuration not found in registry.");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- INITIALIZING INCUBATORS (Setting up Prototypes) ---");
        RobotRegistry registry = new RobotRegistry();
        
        // We do the "hard work" of building from scratch ONLY ONCE per config
        registry.RegisterPrototype("Config A", new Robot("Alpha-Bot", "Configuration A"));
        registry.RegisterPrototype("Config B", new Robot("Beta-Bot", "Configuration B"));
        registry.RegisterPrototype("Config C", new Robot("Gamma-Bot", "Configuration C"));
        
        Console.WriteLine("\n--- \"OKAY, LET'S MAKE SOME CLONES.\" ---");
        
        // Now, we just clone them. Notice the constructor is NOT called again.
        Robot clone1 = registry.CreateClone("Config A");
        clone1.Name = "Alpha-Clone-1"; // We can alter the clone after creation
        clone1.Speak();

        Robot clone2 = registry.CreateClone("Config B");
        clone2.Name = "Beta-Clone-1";
        clone2.Speak();

        Robot clone3 = registry.CreateClone("Config B");
        clone3.Name = "Beta-Clone-2";
        clone3.Speak();
        
        // Verifying they are distinct objects in memory
        Console.WriteLine("\n--- MEMORY CHECK ---");
        Console.WriteLine($"Is clone2 the exact same memory reference as clone3? {ReferenceEquals(clone2, clone3)}");
    }
}