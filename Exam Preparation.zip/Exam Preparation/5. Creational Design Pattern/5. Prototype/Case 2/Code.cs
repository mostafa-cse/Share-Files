using System;
public interface IPrototype
{
    IPrototype Clone();
}

public class ConcretePrototype : IPrototype
{
    private int field1;
    public ConcretePrototype(int field1)
    {
        this.field1 = field1;
    }

    public ConcretePrototype(ConcretePrototype prototype)
    {
        this.field1 = prototype.field1;
    }

    public virtual IPrototype Clone()
    {
        return new ConcretePrototype(this);
    }
    public virtual void Display()
    {
        Console.WriteLine($"ConcretePrototype - field1: {field1}");
    }
}

public class SubclassPrototype : ConcretePrototype
{
    private int field2;

    public SubclassPrototype(int field1, int field2) : base(field1)
    {
        this.field2 = field2;
    }

    public SubclassPrototype(SubclassPrototype prototype) : base(prototype)
    {
        this.field2 = prototype.field2;
    }

    public override IPrototype Clone()
    {
        return new SubclassPrototype(this);
    }

    public override void Display()
    {
        base.Display();
        Console.WriteLine($"SubclassPrototype - field2: {field2}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Original Object ---");
        SubclassPrototype existing = new SubclassPrototype(100, 200);
        existing.Display();

        Console.WriteLine("\n--- Cloned Object ---");
        SubclassPrototype copy = (SubclassPrototype)existing.Clone();
        copy.Display();
        
        Console.WriteLine("\n--- Verification ---");
        Console.WriteLine($"Are they the same reference in memory? {ReferenceEquals(existing, copy)}");
    }
}