using System;
using System.Collections.Generic;

// ── 1. Prototype Interface ────────────────────────────────────────
public interface IPrototype
{
    string GetColor();
    IPrototype Clone();
}

// ── 2. Concrete Prototype ─────────────────────────────────────────
public class Button : IPrototype
{
    private int _x;
    private int _y;
    private string _color;

    // Standard constructor
    public Button(int x, int y, string color)
    {
        _x = x;
        _y = y;
        _color = color;
    }

    // Copy Constructor
    public Button(Button prototype)
    {
        _x = prototype._x;
        _y = prototype._y;
        _color = prototype._color;
    }

    public string GetColor()
    {
        return _color;
    }

    // Note: return new Button(this)
    public IPrototype Clone()
    {
        return new Button(this);
    }

    // Helper method to display state
    public void DisplayInfo(string label)
    {
        Console.WriteLine($"{label} -> Position: ({_x}, {_y}), Color: {_color}");
    }
}

// ── 3. Prototype Registry ─────────────────────────────────────────
public class PrototypeRegistry
{
    // The diagram specifies "items : Prototype[]", but since we need to add 
    // and retrieve by ID, a Dictionary is the most idiomatic C# equivalent.
    private Dictionary<string, IPrototype> _items = new Dictionary<string, IPrototype>();

    public void AddItem(string id, IPrototype p)
    {
        _items[id] = p;
    }

    public IPrototype GetById(string id)
    {
        if (_items.TryGetValue(id, out IPrototype item))
        {
            return item.Clone();
        }
        throw new ArgumentException($"Item with ID '{id}' not found.");
    }

    // Explicitly implementing the note from the diagram:
    // foreach (item in items)
    //   if (item.getColor() == color)
    //       return item.clone()
    public IPrototype GetByColor(string color)
    {
        foreach (var kvp in _items)
        {
            if (kvp.Value.GetColor().Equals(color, StringComparison.OrdinalIgnoreCase))
            {
                return kvp.Value.Clone();
            }
        }
        return null;
    }
}

// ── 4. Client ─────────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        PrototypeRegistry registry = new PrototypeRegistry();

        // Note: button = new Button(10, 40, "red")
        Button originalButton = new Button(10, 40, "red");
        
        // Note: registry.addItem("LandingButton", button)
        registry.AddItem("LandingButton", originalButton);

        // Adding a few more items to populate the registry
        registry.AddItem("CancelButton", new Button(20, 50, "blue"));
        registry.AddItem("SubmitButton", new Button(30, 60, "green"));

        Console.WriteLine("--- Registry Populated ---");
        originalButton.DisplayInfo("Original Landing Button");

        Console.WriteLine("\n--- Retrieving Clones ---");
        
        // Fetching by ID
        Button clonedById = (Button)registry.GetById("LandingButton");
        clonedById.DisplayInfo("Clone retrieved by ID");

        // Note: button = registry.getByColor("red")
        Button clonedByColor = (Button)registry.GetByColor("red");
        clonedByColor.DisplayInfo("Clone retrieved by Color");

        Console.WriteLine("\n--- Memory Verification ---");
        Console.WriteLine($"Are the original and the retrieved clone the same memory reference? {ReferenceEquals(originalButton, clonedByColor)}");
    }
}