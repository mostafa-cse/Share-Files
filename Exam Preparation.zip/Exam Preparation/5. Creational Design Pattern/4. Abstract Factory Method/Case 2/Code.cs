public interface ProductA
{
    void DoSomethingA();
}

public interface ProductB
{
    void DoSomethingB();
}

public class ProductA1 : ProductA
{
    public void DoSomethingA()
    {
        Console.WriteLine("Product A1 is doing its job");
    }
}
public class ProductA2 : ProductA
{
    public void DoSomethingA()
    {
        Console.WriteLine("Product A2 is doing its job");
    }
}

public class ProductB1 : ProductB
{
    public void DoSomethingB()
    {
        Console.WriteLine("Product B1 is doing its job");
    }
    
}
public class ProductB2 : ProductB
{
    public void DoSomethingB()
    {
        Console.WriteLine("Product B2 is doing its job");
    }
}

public abstract class AbstractFactory 
{
    public abstract ProductA CreateProductA();
    public abstract ProductB CreateProductB();
}

public class ConcreteFactory_1 : AbstractFactory
{
    public override ProductA CreateProductA()
    {
        return new ProductA1();
    }
    public override ProductB CreateProductB()
    {
        return new ProductB1();
    }
}

public class ConcreteFactory_2 : AbstractFactory
{
    public override ProductA CreateProductA()
    {
        return new ProductA2();
    }
    public override ProductB CreateProductB()
    {
        return new ProductB2();
    }
}

public class Client
{
    AbstractFactory factory;
    public Client(AbstractFactory factory)
    {
        this.factory = factory;
    }

    public void DoSomething()
    {
        ProductA productA = factory.CreateProductA();
        ProductB productB = factory.CreateProductB();
    }
}

public class Program
{
    public static void Main(String[] args)
    {
        Client client = new Client(new ConcreteFactory_1());
        client.DoSomething();

        client = new Client(new ConcreteFactory_2());
        client.DoSomething();
    }   
}
