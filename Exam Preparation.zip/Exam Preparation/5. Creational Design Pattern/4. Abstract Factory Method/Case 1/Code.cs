using System;

// The Chair interface explicitly defines the methods shown in the UML diagram.
public interface IChair
{
    bool HasLegs();
    void SitOn();
}

public interface ICoffeeTable
{
    void PutCoffeeOn();
}

public interface ISofa
{
    void LieOn();
}

// --- Victorian Family ---

public class VictorianChair : IChair
{
    public bool HasLegs() => true;

    public void SitOn()
    {
        Console.WriteLine("Sitting on a classic Victorian chair.");
    }
}

public class VictorianCoffeeTable : ICoffeeTable
{
    public void PutCoffeeOn()
    {
        Console.WriteLine("Placing coffee on a wooden Victorian coffee table.");
    }
}

public class VictorianSofa : ISofa
{
    public void LieOn()
    {
        Console.WriteLine("Lying on an ornate Victorian sofa.");
    }
}

// --- Modern Family ---

public class ModernChair : IChair
{
    public bool HasLegs() => false; // Modern design might lack traditional legs

    public void SitOn()
    {
        Console.WriteLine("Sitting on a sleek Modern chair.");
    }
}

public class ModernCoffeeTable : ICoffeeTable
{
    public void PutCoffeeOn()
    {
        Console.WriteLine("Placing coffee on a glass Modern coffee table.");
    }
}

public class ModernSofa : ISofa
{
    public void LieOn()
    {
        Console.WriteLine("Lying on a minimalist Modern sofa.");
    }
}


// The Abstract Factory Interface
public interface IFurnitureFactory
{
    IChair CreateChair();
    ICoffeeTable CreateCoffeeTable();
    ISofa CreateSofa();
}

// Concrete Factory for the Victorian family
public class VictorianFurnitureFactory : IFurnitureFactory
{
    public IChair CreateChair()
    {
        return new VictorianChair();
    }

    public ICoffeeTable CreateCoffeeTable()
    {
        return new VictorianCoffeeTable();
    }

    public ISofa CreateSofa()
    {
        return new VictorianSofa();
    }
}

// Concrete Factory for the Modern family
public class ModernFurnitureFactory : IFurnitureFactory
{
    public IChair CreateChair()
    {
        return new ModernChair();
    }

    public ICoffeeTable CreateCoffeeTable()
    {
        return new ModernCoffeeTable();
    }

    public ISofa CreateSofa()
    {
        return new ModernSofa();
    }
}

public class Client
{
    private readonly IChair _chair;
    private readonly ISofa _sofa;
    private readonly ICoffeeTable _coffeeTable;

    // The client only cares that it receives an IFurnitureFactory.
    // It doesn't know (or care) if it's Victorian or Modern.
    public Client(IFurnitureFactory factory)
    {
        _chair = factory.CreateChair();
        _sofa = factory.CreateSofa();
        _coffeeTable = factory.CreateCoffeeTable();
    }

    public void TestFurniture()
    {
        _chair.SitOn();
        _sofa.LieOn();
        _coffeeTable.PutCoffeeOn();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Client testing Victorian Furniture ---");
        IFurnitureFactory victorianFactory = new VictorianFurnitureFactory();
        Client app1 = new Client(victorianFactory);
        app1.TestFurniture();

        Console.WriteLine("\n--- Client testing Modern Furniture ---");
        IFurnitureFactory modernFactory = new ModernFurnitureFactory();
        Client app2 = new Client(modernFactory);
        app2.TestFurniture();
    }
}