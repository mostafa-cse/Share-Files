using System;

public interface IButton
{
    void Render();
}

public interface ICheckBox
{
    void Render();
}

public interface GUIFactory
{
    Button CreateButton();
    CheckBox CreateCheckBox();
}

public class WinButton : IButton
{
    void Render()
    {
        Console.WriteLine("Win button is rendered");
    }
}

public class WinCheckBox : ICheckBox
{
    void Render()
    {
        Console.WriteLine("Win checkbox is rendered");
    }
}

public class MacButton : IButton
{
    void Render()
    {
        Console.WriteLine("Mac button is rendered");
    }
}

public class MacCheckBox : ICheckBox
{
    void Render()
    {
        Console.WriteLine("Mac checkbox is rendered");
    }
}

public class WinFactory : GUIFactory
{
    public IButton CreateButton()
    {
        return new WinButton();
    }

    public ICheckBox CreateCheckBox()
    {
        return new WinCheckBox();
    }
}

public class MacFactory : GUIFactory
{
    public IButton CreateButton()
    {
        return new MacButton();
    }

    public ICheckBox CreateCheckBox()
    {
        return new MacCheckBox();
    }
}

public class Application
{   
   private IButton button;
   private GUIFactory factory;

   public Application(GUIFactory factory)
   {
       this.factory = factory;
   }

    public void createUI()
    {
        button = factory.CreateButton();
    }

    public void paint()
    {
        button.Render();
    }

    public static void Main(string[] args)
    {
        GUIFactory factory = new WinFactory();
        Application app = new Application(factory);
        app.createUI();
        app.paint();
    }
}