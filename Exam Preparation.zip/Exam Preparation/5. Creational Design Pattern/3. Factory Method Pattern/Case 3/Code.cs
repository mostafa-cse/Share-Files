using System;

public interface Button
{
    public void render();
    public void onClick();
}

public class WindowsButton: Button
{
    public void render()
    {
        Console.WriteLine("Windows Button Rendered");
    }
    public void onClick()
    {
        Console.WriteLine("Windows Button Clicked");
    }
}

public class MacButton: Button
{
    public void render()
    {
        Console.WriteLine("Mac Button Rendered");
    }
    public void onClick()
    {
        Console.WriteLine("Mac Button Clicked");
    }   
}

public class LinuxButton: Button
{
    public void render()
    {
        Console.WriteLine("Linux Button Rendered");
    }
    public void onClick()
    {
        Console.WriteLine("Linux Button Clicked");
    }
}

public abstract class Dialog
{
    public abstract Button CreateButton();
    public void Render(){
        Button okButton = CreateButton();
        okButton.onClick();
        okButton.render();
    }
}

public class WindowsDialog: Dialog 
{
    public override Button CreateButton()
    {
        return new WindowsButton();
    }
}

public class MacDialog: Dialog 
{
    public override Button CreateButton()
    {
        return new MacButton();
    }
}

public class LinuxDialog: Dialog
{
    public override Button CreateButton()
    {
        return new LinuxButton();
    }
}

public class Application
{
    private Dialog dialog;

    public Application(Dialog dialog)
    {
        this.dialog = dialog;
    }

    public static void Main(String[] args)
    {
        Console.WriteLine("Enter OS Type: ");
        string osType = Console.ReadLine();
        if(osType == "Windows")
        {
            Application app = new Application(new WindowsDialog());
            app.Main(args);
        }
        else if (osType == "Mac")
        {
            Application app = new Application(new MacDialog());
            app.Main(args);
        }
        else if (osType == "Linux")
        {
            Application app = new Application(new LinuxDialog());
            app.Main(args);
        }
    }
}