/*
Imagine that you're creating a logistics management application. The first version of your app can only
handle transportation by trucks, so the bulk of your code lives inside the Truck class.
After a while, your app becomes pretty popular. Each day you receive dozens of requests from sea
transportation companies to incorporate sea logistics into the app.

--- Factory Method Pattern Implementation ---
- ITransportation  : Product interface
- Truck, Ship      : Concrete Products
- Logistics        : Abstract Creator (declares the factory method)
- RoadLogistics    : Concrete Creator (creates Truck)
- SeaLogistics     : Concrete Creator (creates Ship)
*/

// ── Product Interface ─────────────────────────────────────────────
public interface ITransportation
{
    void Deliver();
}

// ── Concrete Products ─────────────────────────────────────────────
public class Truck : ITransportation
{
    public void Deliver()
    {
        Console.WriteLine("Delivering by truck (road logistics)");
    }
}

public class Ship : ITransportation
{
    public void Deliver()
    {
        Console.WriteLine("Delivering by ship (sea logistics)");
    }
}

// ── Abstract Creator ──────────────────────────────────────────────
// Declares the factory method. Subclasses override it to decide
// which product (transportation) to instantiate.
public abstract class Logistics
{
    // Factory Method
    public abstract ITransportation CreateTransportation();

    // Business logic — delegates object creation to the factory method
    public void PlanDelivery()
    {
        ITransportation transport = CreateTransportation();
        Console.Write("Planning delivery → ");
        transport.Deliver();
    }
}

// ── Concrete Creators ─────────────────────────────────────────────
public class RoadLogistics : Logistics
{
    public override ITransportation CreateTransportation()
    {
        return new Truck();
    }
}

public class SeaLogistics : Logistics
{
    public override ITransportation CreateTransportation()
    {
        return new Ship();
    }
}

// ── Client Code ───────────────────────────────────────────────────
class Program
{
    // Works with any Logistics subtype via the base class reference
    static void ClientCode(Logistics logistics)
    {
        logistics.PlanDelivery();
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("=== Road Logistics ===");
        ClientCode(new RoadLogistics());

        Console.WriteLine();

        Console.WriteLine("=== Sea Logistics ===");
        ClientCode(new SeaLogistics());
    }
}