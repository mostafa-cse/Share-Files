using System;

// =====================================================================================
// 1. PRODUCT INTERFACE
// =====================================================================================
public interface ITheme
{
    string ThemeName { get; }
    string BackgroundColor { get; }
    string ForegroundColor { get; }
    string AccentColor { get; }

    void ApplyTheme();
    void RenderPreview();
}

// =====================================================================================
// 2. CONCRETE PRODUCTS
// =====================================================================================
public class LightTheme : ITheme
{
    public string ThemeName => "Light Theme";
    public string BackgroundColor => "#FAFAFA";
    public string ForegroundColor => "#1F2937";
    public string AccentColor => "#2563EB"; // Royal Blue

    public void ApplyTheme()
    {
        Console.WriteLine($"[Light Mode] ☀️ Applied: Background={BackgroundColor}, Text={ForegroundColor}, Accent={AccentColor}");
    }

    public void RenderPreview()
    {
        Console.WriteLine("┌──────────────────────────────────────────────┐");
        Console.WriteLine("│ ☀️  LIGHT DASHBOARD                           │");
        Console.WriteLine("│  Background: Clean Slate White (#FAFAFA)     │");
        Console.WriteLine("│  Text: Deep Gray-Black (#1F2937)             │");
        Console.WriteLine("│  Button: [ Save Changes ] (Royal Blue)       │");
        Console.WriteLine("└──────────────────────────────────────────────┘");
    }
}

public class DarkTheme : ITheme
{
    public string ThemeName => "Dark Theme";
    public string BackgroundColor => "#0F172A";
    public string ForegroundColor => "#F8FAFC";
    public string AccentColor => "#38BDF8"; // Cyan Glow

    public void ApplyTheme()
    {
        Console.WriteLine($"[Dark Mode] 🌙 Applied: Background={BackgroundColor}, Text={ForegroundColor}, Accent={AccentColor}");
    }

    public void RenderPreview()
    {
        Console.WriteLine("┌──────────────────────────────────────────────┐");
        Console.WriteLine("│ 🌙  DARK DASHBOARD                            │");
        Console.WriteLine("│  Background: Deep Midnight Navy (#0F172A)    │");
        Console.WriteLine("│  Text: Crisp Starlight White (#F8FAFC)       │");
        Console.WriteLine("│  Button: [ Save Changes ] (Neon Cyan Glow)   │");
        Console.WriteLine("└──────────────────────────────────────────────┘");
    }
}

public class SystemTheme : ITheme
{
    private readonly bool _isSystemInDarkHour;

    public SystemTheme()
    {
        // Dynamically detects environment (e.g. system clock or OS setting)
        int currentHour = DateTime.Now.Hour;
        _isSystemInDarkHour = currentHour >= 18 || currentHour < 6; // Dark between 6 PM and 6 AM
    }

    public string ThemeName => $"System Synchronized ({(_isSystemInDarkHour ? "Dark Active" : "Light Active")})";
    public string BackgroundColor => _isSystemInDarkHour ? "#18181B" : "#F4F4F5";
    public string ForegroundColor => _isSystemInDarkHour ? "#E4E4E7" : "#18181B";
    public string AccentColor => "#8B5CF6"; // Purple Adaptive

    public void ApplyTheme()
    {
        string mode = _isSystemInDarkHour ? "Night Schedule (Dark)" : "Day Schedule (Light)";
        Console.WriteLine($"[System Mode] ⚙️ Synchronized with OS: {mode} -> Background={BackgroundColor}, Text={ForegroundColor}");
    }

    public void RenderPreview()
    {
        string icon = _isSystemInDarkHour ? "🌙" : "☀️";
        Console.WriteLine("┌──────────────────────────────────────────────┐");
        Console.WriteLine($"│ ⚙️  SYSTEM ADAPTIVE DASHBOARD {icon}             │");
        Console.WriteLine($"│  Status: Syncing with OS Appearance         │");
        Console.WriteLine($"│  Resolved to: {(_isSystemInDarkHour ? "Midnight Zinc (#18181B)" : "Daylight Zinc (#F4F4F5)")}│");
        Console.WriteLine("│  Button: [ Save Changes ] (Adaptive Purple)  │");
        Console.WriteLine("└──────────────────────────────────────────────┘");
    }
}

// =====================================================================================
// 3. ABSTRACT CREATOR (Declares the Factory Method)
// =====================================================================================
public abstract class ThemeController
{
    // Factory Method to be overridden by subclasses
    public abstract ITheme CreateTheme();

    // Business Logic using the product created by the Factory Method
    public void DisplayDashboard()
    {
        ITheme theme = CreateTheme();
        Console.WriteLine($"\n>>> Initializing: {theme.ThemeName} <<<");
        theme.ApplyTheme();
        theme.RenderPreview();
    }
}

// =====================================================================================
// 4. CONCRETE CREATORS
// =====================================================================================
public class LightThemeController : ThemeController
{
    public override ITheme CreateTheme()
    {
        return new LightTheme();
    }
}

public class DarkThemeController : ThemeController
{
    public override ITheme CreateTheme()
    {
        return new DarkTheme();
    }
}

public class SystemThemeController : ThemeController
{
    public override ITheme CreateTheme()
    {
        return new SystemTheme();
    }
}

// =====================================================================================
// 5. CLIENT CODE
// =====================================================================================
public class Program
{
    public static void RenderUserInterface(ThemeController controller)
    {
        controller.DisplayDashboard();
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("=================================================");
        Console.WriteLine("    UI THEME ENGINE (FACTORY METHOD DEMO)        ");
        Console.WriteLine("=================================================");

        string[] themeModes = { "light", "dark", "system" };

        foreach (var mode in themeModes)
        {
            ThemeController controller = mode.ToLower() switch
            {
                "light" => new LightThemeController(),
                "dark" => new DarkThemeController(),
                "system" => new SystemThemeController(),
                _ => throw new ArgumentException("Unknown theme mode")
            };

            RenderUserInterface(controller);
        }
    }
}
