using System;

public interface IProduct
{
    public void doStuff();
}

public class ConcreateProduct1 : IProduct
{
    public void doStuff()
    {
        Console.WriteLine("Product 1 is doing stuff");
    }
}
public class ConcreateProduct2 : IProduct
{
    public void doStuff()
    {
        Console.WriteLine("Product 2 is doing stuff");
    }
}

public abstract class Creator // factory pattern 
{
    protected abstract IProduct FactoryMethod();
    public void SomeOperation()
    {
        IProduct product = FactoryMethod();
        Console.WriteLine(product.ToString());
        product.doStuff();
    }
}

public class ConcreteCreator1 : Creator
{
    protected override IProduct FactoryMethod()
    {
        return new ConcreateProduct1();
    }
}

public class ConcreteCreator2 : Creator
{
    protected override IProduct FactoryMethod()
    {
        return new ConcreateProduct2();
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Creator creator = new ConcreteCreator1();
        creator.SomeOperation();
    }
}
