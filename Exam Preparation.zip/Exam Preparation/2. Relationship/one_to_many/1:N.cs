/*
    One-to-Many Relationship (একের সাথে অনেক)

    ধারণা: একটি ক্লাসের একটি অবজেক্টের আন্ডারে অন্য ক্লাসের একাধিক অবজেক্ট থাকে।

    উদাহরণ: একটি Department 🏢 (যেমন- IT ডিপার্টমেন্ট)-এ অনেকজন Employee 👥 (কর্মী) কাজ করেন।
    - কোডের মাধ্যমে: Department ক্লাসের ভেতরে Employee ক্লাসের লিস্ট রেখেছি।
*/

using System.Collections.Generic;

public class Employee
{
    public string Name { get; set; }
}

public class Department
{
    public string DepartmentName { get; set; }
    
    // One-to-Many: একটি ডিপার্টমেন্টে অনেক কর্মী। তাই আমরা List ব্যবহার করেছি।
    public List<Employee> Employees { get; set; } = new List<Employee>();
}