/*
    Many-to-Many Relationship (অনেকের সাথে অনেক)

    ধারণা: একটি ক্লাসের একাধিক অবজেক্ট অন্য ক্লাসের একাধিক অবজেক্টের সাথে যুক্ত থাকে।

    উদাহরণ: ছাত্র (Student) 🎓 এবং কোর্স (Course) 📚। একজন ছাত্র একাধিক কোর্সে ভর্তি হতে পারে, আবার একটি কোর্সে একাধিক ছাত্র থাকতে পারে।
    - কোডের মাধ্যমে: Student ক্লাসের ভেতরে List<Course> এবং Course ক্লাসের ভেতরে List<Student> ব্যবহার করেছি।
*/

using System.Collections.Generic;

public class Course
{
    public string CourseName
    {
        get;
        set;
    }

    // Many-to-Many: একটি কোর্সে অনেক ছাত্র থাকতে পারে
    public List<Student> Students
    {
        get;
        set;
    } = new List<Student>();
}

public class Student
{
    public string StudentName
    {
        get;
        set;
    }

    // Many-to-Many: একজন ছাত্র অনেক কোর্স নিতে পারে
    public List<Course> Courses
    {
        get;
        set;
    } = new List<Course>();
}