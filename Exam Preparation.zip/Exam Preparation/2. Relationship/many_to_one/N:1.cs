public class Department
{
    public string DepartmentName
    {
        get;
        set;
    }
}

public class Employee
{
    public string EmployeeName
    {
        get;
        set;
    }

    // Many-to-One: একজন কর্মীর জন্য একটিমাত্র নির্দিষ্ট ডিপার্টমেন্ট থাকে
    public Department MyDepartment
    {
        get;
        set;
    }
}