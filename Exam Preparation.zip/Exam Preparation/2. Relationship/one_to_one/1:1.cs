/*
    ১. One-to-One Relationship (একের সাথে এক)

    - ধারণা: একটি ক্লাসের একটি অবজেক্ট যখন অন্য ক্লাসের ঠিক একটি অবজেক্টের সাথেই যুক্ত থাকে।

    - উদাহরণ: একজন মানুষের 🧑 একটিমাত্র পাসপোর্ট 🛂 থাকে।
    - কোডের মাধ্যমে: Person ক্লাসের ভেতরে আমরা Passport ক্লাসের একটিমাত্র রেফারেন্স রেখেছি। এটাই হলো কোডে One-to-One রিলেশন তৈরি করার নিয়ম।
*/

public class Passport
{
    public string PassportNumber
    {
        get;
        set;
    }
}

public class Person
{
    public string Name
    {
        get;
        set;
    }

    // Person ক্লাসের ভেতরে Passport ক্লাসের একটিমাত্র অবজেক্ট (One-to-One)
    public Passport MyPassport
    {
        get;
        set;
    }
}