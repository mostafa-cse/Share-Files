using System;

// ── 1. The Target ─────────────────────────────────────────────────
// The class the client (RoundHole) expects to work with.
public class RoundPeg
{
    private int _radius;

    // Default constructor needed for the Adapter to inherit properly 
    // without needing to pass a dummy radius.
    public RoundPeg() { }

    public RoundPeg(int radius)
    {
        _radius = radius;
    }

    // Must be virtual so the Adapter can override it with math logic
    public virtual int GetRadius()
    {
        return _radius;
    }
}

// ── 2. The Client ─────────────────────────────────────────────────
public class RoundHole
{
    private int _radius;

    public RoundHole(int radius)
    {
        _radius = radius;
    }

    public int GetRadius()
    {
        return _radius;
    }

    // This method ONLY accepts RoundPegs
    public bool Fits(RoundPeg peg)
    {
        return this.GetRadius() >= peg.GetRadius();
    }
}

// ── 3. The Adaptee (Incompatible Class) ───────────────────────────
public class SquarePeg
{
    private int _width;

    public SquarePeg(int width)
    {
        _width = width;
    }

    public int GetWidth()
    {
        return _width;
    }
}

// ── 4. The Adapter ────────────────────────────────────────────────
// Extends RoundPeg so it can be passed into the RoundHole, 
// but wraps a SquarePeg under the hood.
public class SquarePegAdapter : RoundPeg
{
    private SquarePeg _peg;

    public SquarePegAdapter(SquarePeg peg)
    {
        _peg = peg;
    }

    // Overrides the base behavior to calculate the bounding circle's radius
    public override int GetRadius()
    {
        // Math note: return peg.getWidth() * sqrt(2) / 2
        // Calculates half the diagonal of the square.
        double result = _peg.GetWidth() * Math.Sqrt(2) / 2;
        return (int)result;
    }
}

// ── Execution ─────────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Testing Pegs & Holes ---");
        
        RoundHole hole = new RoundHole(5);
        RoundPeg rPeg = new RoundPeg(5);
        
        Console.WriteLine($"Does the round peg (r:5) fit in the hole (r:5)? {hole.Fits(rPeg)}");

        SquarePeg smallSqPeg = new SquarePeg(5);
        SquarePeg largeSqPeg = new SquarePeg(10);
        
        // hole.Fits(smallSqPeg); // ERROR: Won't compile. Incompatible types.

        // Wrap the incompatible square pegs in the adapter
        SquarePegAdapter smallAdapter = new SquarePegAdapter(smallSqPeg);
        SquarePegAdapter largeAdapter = new SquarePegAdapter(largeSqPeg);

        Console.WriteLine($"Does the small square peg (w:5) fit? {hole.Fits(smallAdapter)}");
        Console.WriteLine($"Does the large square peg (w:10) fit? {hole.Fits(largeAdapter)}");
    }
}