using System;

// ── Shared Service (The Incompatible Class) ───────────────────────
// Both adapter patterns will wrap this service. It expects an integer (specialData).
public class Service
{
    public void ServiceMethod(int specialData)
    {
        Console.WriteLine($"[Service] Successfully processed special data: {specialData}");
    }
}

// ==================================================================
// APPROACH 1: OBJECT ADAPTER (Based on image_016f1d.png)
// ==================================================================

// 1. The Interface expected by the client
public interface IClientInterface
{
    void Method(string data);
}

// 2. The Object Adapter (Uses Composition/Aggregation)
public class ObjectAdapter : IClientInterface
{
    private readonly Service _adaptee;

    public ObjectAdapter(Service adaptee)
    {
        _adaptee = adaptee;
    }

    public void Method(string data)
    {
        Console.WriteLine($"[Object Adapter] Received string data: '{data}'");
        
        // specialData = convertToServiceFormat(data)
        if (int.TryParse(data, out int specialData))
        {
            // return adaptee.serviceMethod(specialData)
            _adaptee.ServiceMethod(specialData);
        }
        else
        {
            Console.WriteLine("[Object Adapter] Error: Could not convert data.");
        }
    }
}

// ==================================================================
// APPROACH 2: CLASS ADAPTER (Based on image_016efb.png)
// ==================================================================

// 1. The Existing Target (Must be an interface in C# to allow multiple inheritance)
public interface IExistingClass
{
    void Method(string data);
}

// 2. The Class Adapter (Uses Multiple Inheritance)
// Inherits the implementation of 'Service' and the contract of 'IExistingClass'
public class ClassAdapter : Service, IExistingClass
{
    public void Method(string data)
    {
        Console.WriteLine($"[Class Adapter] Received string data: '{data}'");
        
        // specialData = convertToServiceFormat(data)
        if (int.TryParse(data, out int specialData))
        {
            // return serviceMethod(specialData) -> Called directly from base class!
            this.ServiceMethod(specialData); 
        }
        else
        {
            Console.WriteLine("[Class Adapter] Error: Could not convert data.");
        }
    }
}

// ── Client Application ────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        string incompatibleData = "404";

        Console.WriteLine("--- Testing Object Adapter ---");
        Service service = new Service();
        IClientInterface objectAdapter = new ObjectAdapter(service);
        objectAdapter.Method(incompatibleData);

        Console.WriteLine("\n--- Testing Class Adapter ---");
        IExistingClass classAdapter = new ClassAdapter();
        classAdapter.Method(incompatibleData);
    }
}