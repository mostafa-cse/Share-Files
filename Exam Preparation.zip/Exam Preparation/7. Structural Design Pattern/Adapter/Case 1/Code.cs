using System;

// ── Domain Models ─────────────────────────────────────────────────
public class XmlData 
{ 
    public string XmlString { get; set; } 
}

public class JsonData 
{ 
    public string JsonString { get; set; } 
}

// ── 1. The Existing Data Provider ─────────────────────────────────
// Simulates the "Stock Data Provider" returning XML.
public class StockDataProvider
{
    public XmlData GetStockData()
    {
        return new XmlData { XmlString = "<stock><ticker>AAPL</ticker><price>150</price></stock>" };
    }
}

// ── 2. The Incompatible Adaptee ───────────────────────────────────
// Simulates the 3rd-party "Analytics Library" that only accepts JSON.
public class AnalyticsLibrary
{
    public void AnalyzeData(JsonData jsonData)
    {
        Console.WriteLine($"[Analytics Library] Successfully analyzing JSON data: {jsonData.JsonString}");
    }
}

// ── 3. The Adapter ────────────────────────────────────────────────
// The middleman that bridges the gap between XML and JSON.
public class XmlToJsonAdapter
{
    private AnalyticsLibrary _analyticsLibrary;

    // The Adapter wraps the incompatible library via its constructor
    public XmlToJsonAdapter(AnalyticsLibrary analyticsLibrary)
    {
        _analyticsLibrary = analyticsLibrary;
    }

    // The method the Application will actually call, passing the XML
    public void ProcessData(XmlData xmlData)
    {
        Console.WriteLine($"[Adapter] Received XML: {xmlData.XmlString}");
        Console.WriteLine("[Adapter] Translating XML to JSON...");

        // Simulate the data conversion process
        JsonData jsonData = new JsonData { JsonString = "{ \"ticker\": \"AAPL\", \"price\": 150 }" };

        Console.WriteLine("[Adapter] Forwarding translated JSON to the Analytics Library.");
        
        // Pass the translated data to the wrapped library
        _analyticsLibrary.AnalyzeData(jsonData);
    }
}

// ── 4. The Application (Client) ───────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Fetching Data ---");
        StockDataProvider provider = new StockDataProvider();
        XmlData stockData = provider.GetStockData();

        Console.WriteLine("\n--- Setting up the Adapter ---");
        // We want to use this library, but it's incompatible with our XML
        AnalyticsLibrary analytics = new AnalyticsLibrary();
        
        // We wrap the library in our adapter
        XmlToJsonAdapter adapter = new XmlToJsonAdapter(analytics);

        Console.WriteLine("\n--- Executing Application Logic ---");
        // The application seamlessly processes the data through the adapter
        adapter.ProcessData(stockData);
    }
}