using System;

// ── 1. Component Interface ────────────────────────────────────────
// Represents the top "Notifier" block in image_03a617.png
public interface INotifier
{
    void Send(string message);
}

// ── 2. Concrete Component ─────────────────────────────────────────
// The core notification class that gets wrapped by the decorators.
public class Notifier : INotifier
{
    public void Send(string message)
    {
        Console.WriteLine($"[Email] Sending standard email notification: {message}");
    }
}

// ── 3. Base Decorator ─────────────────────────────────────────────
// Corresponds directly to the "BaseDecorator" in image_03a617.png
public abstract class BaseDecorator : INotifier
{
    // Note: - wrappee: Notifier
    protected INotifier _wrappee;

    public BaseDecorator(INotifier notifier)
    {
        _wrappee = notifier;
    }

    // Note: wrappee.send(message);
    public virtual void Send(string message)
    {
        if (_wrappee != null)
        {
            _wrappee.Send(message);
        }
    }
}

// ── 4. Concrete Decorators ────────────────────────────────────────
// They inherit from BaseDecorator and add their specific behavior.

public class SMSDecorator : BaseDecorator
{
    public SMSDecorator(INotifier notifier) : base(notifier) { }

    public override void Send(string message)
    {
        // Note: super::send(message);
        base.Send(message);
        
        // Note: sendSMS(message);
        SendSMS(message);
    }

    private void SendSMS(string message)
    {
        Console.WriteLine($"[SMS] Sending SMS notification: {message}");
    }
}

public class FacebookDecorator : BaseDecorator
{
    public FacebookDecorator(INotifier notifier) : base(notifier) { }

    public override void Send(string message)
    {
        base.Send(message);
        SendFacebook(message);
    }

    private void SendFacebook(string message)
    {
        Console.WriteLine($"[Facebook] Sending Facebook message: {message}");
    }
}

public class SlackDecorator : BaseDecorator
{
    public SlackDecorator(INotifier notifier) : base(notifier) { }

    public override void Send(string message)
    {
        base.Send(message);
        SendSlack(message);
    }

    private void SendSlack(string message)
    {
        Console.WriteLine($"[Slack] Sending Slack alert: {message}");
    }
}

// ── 5. Client Application ─────────────────────────────────────────
// Based on the Application class in image_03a95d.png
public class Application
{
    private INotifier _notifier;

    public void SetNotifier(INotifier notifier)
    {
        _notifier = notifier;
    }

    public void DoSomething()
    {
        Console.WriteLine("\nApplication is performing an important task...");
        
        // Trigger the notification stack
        // Note: notifier.send("Alert!")
        _notifier?.Send("Alert! Important task completed.");
    }
}

// ── 6. Execution / Program ────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        Application app = new Application();

        Console.WriteLine("--- Scenario 1: Basic Email Only ---");
        INotifier emailNotifier = new Notifier();
        app.SetNotifier(emailNotifier);
        app.DoSomething();

        Console.WriteLine("\n--- Scenario 2: Email + SMS + Slack ---");
        // This completely solves the issue shown in image_03a675.png!
        // We just wrap the objects inside one another instead of making huge subclasses.
        INotifier stack = new Notifier();
        stack = new SMSDecorator(stack);
        stack = new SlackDecorator(stack);
        
        app.SetNotifier(stack);
        app.DoSomething();

        Console.WriteLine("\n--- Scenario 3: ALL Notifications (The Works) ---");
        INotifier allNotifier = new FacebookDecorator(
                                    new SlackDecorator(
                                        new SMSDecorator(
                                            new Notifier())));
        
        app.SetNotifier(allNotifier);
        app.DoSomething();
    }
}