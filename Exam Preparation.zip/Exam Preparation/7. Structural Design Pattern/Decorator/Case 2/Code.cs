using System;

// ── 1. Component Interface ────────────────────────────────────────
// Defines the common interface for both wrappers and wrapped objects.
public interface IComponent
{
    void Execute();
}

// ── 2. Concrete Component ─────────────────────────────────────────
// The core object that will have behaviors dynamically added to it.
public class ConcreteComponent : IComponent
{
    public void Execute()
    {
        Console.WriteLine("ConcreteComponent: Executing core behavior.");
    }
}

// ── 3. Base Decorator ─────────────────────────────────────────────
// The base class that maintains the reference to the wrapped object.
public abstract class BaseDecorator : IComponent
{
    // Note: - wrappee: Component
    protected IComponent _wrappee;

    // Note: wrappee = c
    public BaseDecorator(IComponent c)
    {
        _wrappee = c;
    }

    // Note: wrappee.execute()
    public virtual void Execute()
    {
        if (_wrappee != null)
        {
            _wrappee.Execute();
        }
    }
}

// ── 4. Concrete Decorators ────────────────────────────────────────
// Extends the base decorator to add specific behaviors.

public class ConcreteDecorator1 : BaseDecorator
{
    public ConcreteDecorator1(IComponent c) : base(c) { }

    public override void Execute()
    {
        // Note: super::execute()
        base.Execute();
        
        // Note: extra()
        Extra();
    }

    private void Extra()
    {
        Console.WriteLine("ConcreteDecorator1: Adding extra behavior 1.");
    }
}

public class ConcreteDecorator2 : BaseDecorator
{
    public ConcreteDecorator2(IComponent c) : base(c) { }

    public override void Execute()
    {
        // Note: super::execute()
        base.Execute();
        
        // Note: extra()
        Extra();
    }

    private void Extra()
    {
        Console.WriteLine("ConcreteDecorator2: Adding extra behavior 2.");
    }
}

// ── 5. Client ─────────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        // -------------------------------------------------------------
        // Executing the exact logic from the Client note (Note #5)
        // -------------------------------------------------------------
        
        // a = new ConcComponent()
        IComponent a = new ConcreteComponent();
        
        // b = new ConcDecorator1(a)
        IComponent b = new ConcreteDecorator1(a);
        
        // c = new ConcDecorator2(b)
        IComponent c = new ConcreteDecorator2(b);
        
        Console.WriteLine("--- Executing the decorated chain ---");
        
        // c.execute()
        // Expected flow: Decorator -> Decorator -> Component
        c.Execute();
    }
}