using System;

public interface IDataSource
{
    void WriteData(string data);
    string ReadData();
}

public class FileDataSource : IDataSource
{
    string fileName;
    public FileDataSource(string fileName)
    {
        this.fileName = fileName;
    }
    public void WriteData(string data)
    {
        Console.WriteLine("Writing data to file: " + data);
    }
    public string ReadData()
    {
        return "Data from file.";
    }
}

public class DataSourceDecorator : IDataSource
{
    protected IDataSource dataSource;
    public DataSourceDecorator(IDataSource dataSource)
    {
        this.dataSource = dataSource;
    }
    public virtual void WriteData(string data)
    {
        dataSource.WriteData(data);
    }
    public virtual string ReadData()
    {
        return dataSource.ReadData();
    }
}

class EncryptionDecorator : DataSourceDecorator
{
    public EncryptionDecorator(IDataSource dataSource) : base(dataSource)
    {
        
    }
    public override void WriteData(string data)
    {
        Console.WriteLine("Encrypting data...");
        base.WriteData(data);
    }
    public override string ReadData()
    {
        string data = base.ReadData();
        Console.WriteLine("Decrypting data...");
        return data;
    }
}
class CompressionDecorator : DataSourceDecorator
{
    public CompressionDecorator(IDataSource dataSource) : base(dataSource)
    {
        
    }
    public override void WriteData(string data)
    {
        Console.WriteLine("Compressing data...");
        base.WriteData(data);
    }
    public override string ReadData()
    {
        string data = base.ReadData();
        Console.WriteLine("Decompressing data...");
        return data;
    }
}


class Program
{
    public static void Main(string[] args)
    {
        IDataSource dataSource = new FileDataSource("file.txt");
        dataSource = new CompressionDecorator(new EncryptionDecorator(dataSource));
        dataSource.WriteData("Hello World");
        Console.WriteLine(dataSource.ReadData());
    }
}