using System;
using System.Collections.Generic;

// ── 1. Interface ──────────────────────────────────────────────────
public interface IComponentWithContextualHelp
{
    void ShowHelp();
}

// ── 2. Base Component ─────────────────────────────────────────────
// Acts as the base link in the Chain of Responsibility.
public abstract class Component : IComponentWithContextualHelp
{
    // The "next" link in the chain (pointing up the UI tree)
    public Container ParentContainer { get; set; }
    
    public string TooltipText { get; set; }
    public string Name { get; set; } // Helper property for console output

    public virtual void ShowHelp()
    {
        // Note: if (tooltipText != null) // Show tooltip... 
        //       else // ...or ask the container to do it. container.showHelp()
        if (TooltipText != null)
        {
            Console.WriteLine($"[Component: {Name}] Showing Tooltip: {TooltipText}");
        }
        else if (ParentContainer != null)
        {
            Console.WriteLine($"[Component: {Name}] No tooltip found. Passing request to parent container...");
            ParentContainer.ShowHelp();
        }
        else
        {
            Console.WriteLine($"[Component: {Name}] Reached top of chain. No help available.");
        }
    }
}

// ── 3. Composite Container ────────────────────────────────────────
// Represents UI elements that can contain other UI elements.
public class Container : Component
{
    protected List<Component> _children = new List<Component>();

    public void Add(Component child)
    {
        _children.Add(child);
        // CRITICAL: When adding a child, set its parent to this container.
        // This builds the upward Chain of Responsibility!
        child.ParentContainer = this; 
    }
}

// ── 4. Concrete Components & Containers ───────────────────────────

public class Button : Component
{
    // Note: Inherits showHelp behavior entirely from the parent Component class.
    public Button(string name) { Name = name; }
}

public class Panel : Container
{
    public string ModalHelpText { get; set; }

    public Panel(string name) { Name = name; }

    public override void ShowHelp()
    {
        // Note: if (modalHelpText != null) // Show modal window... 
        //       else parent::showHelp()
        if (ModalHelpText != null)
        {
            Console.WriteLine($"[Panel: {Name}] Showing Modal Help: {ModalHelpText}");
        }
        else
        {
            Console.WriteLine($"[Panel: {Name}] No modal help found. Passing to parent...");
            base.ShowHelp(); // Bubbles up to base Component logic (which checks Tooltip then Parent)
        }
    }
}

public class Dialog : Container
{
    public string WikiPageURL { get; set; }

    public Dialog(string name) { Name = name; }

    public override void ShowHelp()
    {
        // Note: if (wikiPageURL != null) // Open a wiki page... 
        //       else parent::showHelp()
        if (WikiPageURL != null)
        {
            Console.WriteLine($"[Dialog: {Name}] Opening Wiki Page URL: {WikiPageURL}");
        }
        else
        {
            Console.WriteLine($"[Dialog: {Name}] No wiki URL found. Passing to parent...");
            base.ShowHelp();
        }
    }
}

// ── 5. Client Execution ───────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        // 1. Build the UI Tree (Composite structure)
        Dialog appDialog = new Dialog("Main App Dialog") { WikiPageURL = "http://wiki.company.com/app-help" };
        
        Panel settingsPanel = new Panel("Settings Panel"); // Intentionally leaving ModalHelpText null
        Panel advancedPanel = new Panel("Advanced Panel") { ModalHelpText = "Warning: Advanced settings can break things." };
        
        Button okButton = new Button("OK Button"); // No tooltip
        Button saveButton = new Button("Save Button") { TooltipText = "Saves your current progress." };

        // 2. Link them together (Establishing the Chain)
        appDialog.Add(settingsPanel);
        appDialog.Add(advancedPanel);
        
        settingsPanel.Add(okButton);
        advancedPanel.Add(saveButton);

        // 3. Trigger Help Requests
        Console.WriteLine("--- Scenario 1: Button has its own help ---");
        saveButton.ShowHelp(); 
        // Expected: Save Button handles it immediately.

        Console.WriteLine("\n--- Scenario 2: Button asks Panel, Panel handles it ---");
        // We temporarily move 'okButton' to the 'advancedPanel' to test this
        advancedPanel.Add(okButton); 
        okButton.ShowHelp(); 
        // Expected: OK Button -> Advanced Panel (Shows Modal).

        Console.WriteLine("\n--- Scenario 3: Request bubbles all the way to the top Dialog ---");
        settingsPanel.Add(okButton); // Move back to settings panel
        okButton.ShowHelp(); 
        // Expected: OK Button -> Settings Panel -> Main App Dialog (Shows Wiki).
    }
}