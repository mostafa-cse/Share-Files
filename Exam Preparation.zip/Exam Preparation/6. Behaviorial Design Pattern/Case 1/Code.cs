using System;

// ── 1. The Handler Interface ───────────────────────────────────────
// Defines the contract for all handlers in the chain.
public interface IHandler
{
    IHandler SetNext(IHandler handler);
    object Handle(object request);
}

// ── 2. Base Handler ────────────────────────────────────────────────
// Implements the boilerplate chaining logic so concrete handlers don't have to.
public abstract class AbstractHandler : IHandler
{
    private IHandler _nextHandler;

    public IHandler SetNext(IHandler handler)
    {
        _nextHandler = handler;
        // Returning the handler allows us to link them in a fluent chain:
        // handler1.SetNext(handler2).SetNext(handler3);
        return handler;
    }

    public virtual object Handle(object request)
    {
        // If there is a next handler in the chain, pass the request along
        if (_nextHandler != null)
        {
            return _nextHandler.Handle(request);
        }
        
        // End of the chain (Request passed all checks)
        return null;
    }
}

// ── 3. Concrete Handlers ───────────────────────────────────────────
// Each handler does one specific job. It can either halt the chain or pass it on.

public class AuthenticationHandler : AbstractHandler
{
    public override object Handle(object request)
    {
        if (request.ToString() == "UnauthenticatedUser")
        {
            return "[Error] AuthenticationHandler: Request denied. User is not logged in.";
        }
        
        Console.WriteLine("AuthenticationHandler: User verified. Passing to next handler...");
        return base.Handle(request);
    }
}

public class AuthorizationHandler : AbstractHandler
{
    public override object Handle(object request)
    {
        if (request.ToString() == "UnauthorizedUser")
        {
            return "[Error] AuthorizationHandler: Request denied. User lacks admin privileges.";
        }
        
        Console.WriteLine("AuthorizationHandler: Permissions verified. Passing to next handler...");
        return base.Handle(request);
    }
}

public class ValidationHandler : AbstractHandler
{
    public override object Handle(object request)
    {
        if (request.ToString() == "InvalidPayload")
        {
            return "[Error] ValidationHandler: Request denied. Data payload is malformed.";
        }
        
        Console.WriteLine("ValidationHandler: Data validated. Passing to next handler...");
        return base.Handle(request);
    }
}

// ── 4. Client Application ──────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        // Setup the Chain of Responsibility
        var authentication = new AuthenticationHandler();
        var authorization = new AuthorizationHandler();
        var validation = new ValidationHandler();

        // Link them together: Auth -> Authz -> Validation
        authentication.SetNext(authorization).SetNext(validation);

        Console.WriteLine("--- Scenario 1: Valid Request ---");
        var result1 = authentication.Handle("ValidRequest");
        if (result1 == null) 
        {
            Console.WriteLine("SUCCESS: Request reached the Ordering System!");
        }

        Console.WriteLine("\n--- Scenario 2: Unauthorized Request ---");
        var result2 = authentication.Handle("UnauthorizedUser");
        if (result2 != null) 
        {
            Console.WriteLine(result2); // Chain was halted
        }
    }
}