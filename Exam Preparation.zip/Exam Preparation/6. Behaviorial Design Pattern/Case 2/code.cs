using System;

// ── 1. Handler Interface ──────────────────────────────────────────
// Defines the common contract for all handlers.
public interface IHandler
{
    IHandler SetNext(IHandler h);
    void Handle(string request);
}

// ── 2. Base Handler ───────────────────────────────────────────────
// Implements the chaining mechanism so concrete classes don't have to.
public abstract class BaseHandler : IHandler
{
    // Note: - next: Handler
    private IHandler _next;

    public IHandler SetNext(IHandler h)
    {
        _next = h;
        // Returning the handler allows for convenient chaining in the client
        return h;
    }

    public virtual void Handle(string request)
    {
        // Note: if (next != null) next.handle(request)
        if (_next != null)
        {
            _next.Handle(request);
        }
        else
        {
            Console.WriteLine($"[End of Chain] Request '{request}' was left unhandled.");
        }
    }
}

// ── 3. Concrete Handlers ──────────────────────────────────────────
// Specific handlers that decide whether to process the request or pass it along.

public class HandlerA : BaseHandler
{
    public override void Handle(string request)
    {
        // Note: if (canHandle(request)) { ... } else { parent::handle(request) }
        if (CanHandle(request))
        {
            Console.WriteLine($"[Handler A] Successfully processed request: {request}");
        }
        else
        {
            Console.WriteLine("[Handler A] Cannot handle. Passing to next...");
            base.Handle(request); // parent::handle(request)
        }
    }

    private bool CanHandle(string request) => request == "A";
}

public class HandlerB : BaseHandler
{
    public override void Handle(string request)
    {
        if (CanHandle(request))
        {
            Console.WriteLine($"[Handler B] Successfully processed request: {request}");
        }
        else
        {
            Console.WriteLine("[Handler B] Cannot handle. Passing to next...");
            base.Handle(request);
        }
    }

    private bool CanHandle(string request) => request == "B";
}

public class HandlerC : BaseHandler
{
    public override void Handle(string request)
    {
        if (CanHandle(request))
        {
            Console.WriteLine($"[Handler C] Successfully processed request: {request}");
        }
        else
        {
            Console.WriteLine("[Handler C] Cannot handle. Passing to next...");
            base.Handle(request);
        }
    }

    private bool CanHandle(string request) => request == "C";
}

// ── 4. Client ─────────────────────────────────────────────────────
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("--- Building the Chain ---");
        
        // Note: h1 = new HandlerA()
        // Note: h2 = new HandlerB()
        // Note: h3 = new HandlerC()
        IHandler h1 = new HandlerA();
        IHandler h2 = new HandlerB();
        IHandler h3 = new HandlerC();

        // Note: h1.setNext(h2)
        // Note: h2.setNext(h3)
        h1.SetNext(h2).SetNext(h3);

        Console.WriteLine("\n--- Sending Request 'B' ---");
        // Note: h1.handle(request)
        h1.Handle("B");

        Console.WriteLine("\n--- Sending Request 'C' ---");
        h1.Handle("C");

        Console.WriteLine("\n--- Sending Request 'Z' (Unhandled) ---");
        h1.Handle("Z");
    }
}