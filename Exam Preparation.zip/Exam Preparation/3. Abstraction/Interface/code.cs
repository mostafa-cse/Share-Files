namespace InterfaceExample
{
    // Interface তৈরি করা (C#-এ সাধারণত ইন্টারফেসের নামের শুরুতে 'I' দেওয়া হয়)
    public interface ICoffeeMaker
    {
        // ইন্টারফেসে মেথডের বডি থাকে না এবং ডিফল্টভাবেই public থাকে
        void Brew();
    }
}
// class interface implement 
namespace InterfaceExample
{
    public class MyCoffeeMachine : ICoffeeMaker
    {
        // abstract ক্লাসের মতো এখানেও মেথডের লজিক লিখতে হয়
        public void Brew()
        {
            Console.WriteLine("Brewing coffee... ☕");
        }

        public void Serve()
        {
            Console.WriteLine("Coffee served! ☕");
        }

        public void TurnOn()
        {
            Console.WriteLine("Machine turning on... ☕");
        }
    }
}
