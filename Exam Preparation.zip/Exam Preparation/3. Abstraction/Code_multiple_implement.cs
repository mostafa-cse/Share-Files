// একটি প্যারেন্ট ক্লাস (Machine) এবং দুটি ইন্টারফেস (ICoffee, IWifi)
public class SmartCoffeeMachine : Machine, ICoffee, IWifi 
{
    // ...
}