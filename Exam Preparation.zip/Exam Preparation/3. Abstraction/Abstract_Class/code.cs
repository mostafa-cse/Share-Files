// Abstract Class (ব্লুপ্রিন্ট)
public abstract class CoffeeMaker
{
    // Abstract Method (যার কোনো বডি বা লজিক নেই)
    public abstract void Brew();
    public abstract void BoilWater();
    public abstract void GrindBeans();
    public abstract void Serve();


    // concrete method with implementation
    public void TurnOn()
    {
        Console.WriteLine("Coffee machine is turning on... ☕");
    }
    public void TurnOff()
    {
        Console.WriteLine("Coffee machine is turning off... ☕");
    }
}

// Child Class
public class MyCoffeeMachine : CoffeeMaker
{
    // এখানে Brew() মেথডটি সম্পূর্ণ করতে হবে
    public override void Brew()
    {
        Console.WriteLine("Coffee is brewing... ☕");
    }
    public override void BoilWater()
    {
        Console.WriteLine("Water is boiling... ☕");
    }
    public override void GrindBeans()
    {
        Console.WriteLine("Beans are grinding... ☕");
    }
    public override void Serve()
    {
        Console.WriteLine("Coffee is served... ☕");
    }
}