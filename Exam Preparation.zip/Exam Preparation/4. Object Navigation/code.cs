public class Passport
{
    public string PassportNumber { get; set; }
    public string PlaceOfIssue { get; set; }
}

public class Person
{
    public int PersonId { get; set; }
    public string Name { get; set; }
    public Passport MyPassport { get; set; }
}

public class main
{
    public static void Main()
    {
        Person john = new Person
        {
            Name = "John",
            MyPassport = new Passport
            {
                PassportNumber = "123456789",
                PlaceOfIssue = "Dhaka"
            }
        };

        Console.WriteLine(john.MyPassport.PassportNumber);
    }
}