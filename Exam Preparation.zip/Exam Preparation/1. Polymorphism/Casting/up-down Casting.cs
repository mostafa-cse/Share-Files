using System;

// Parent Class
class Mobile
{
    public void Call() 
    { 
        Console.WriteLine("Making a normal call... 📞"); 
    }
}

// Child Class
class Smartphone : Mobile
{
    public void BrowseInternet() 
    { 
        Console.WriteLine("Browsing the internet using 5G! 🌐"); 
    }
}

public class Program
{
    public static void Main()
    {
        // Upcasting (Child -> Parent)
        Mobile myDevice = new Smartphone(); 
        myDevice.Call(); //  কাজ করবে (কারণ সব মোবাইলেই কল করা যায়)
        
        // myDevice.BrowseInternet(); 
        //  Error! myDevice এখন Mobile রেফারেন্সে আছে, তাই সে ইন্টারনেট চেনে না।

        // Downcasting (Parent -> Child)
        // আমরা জানি myDevice আসলে ভেতরে একটি Smartphone, তাই আমরা তাকে কাস্ট করছি:
        Smartphone mySmartDevice = (Smartphone)myDevice;
        mySmartDevice.BrowseInternet(); //  এখন কাজ করবে!
    }
}