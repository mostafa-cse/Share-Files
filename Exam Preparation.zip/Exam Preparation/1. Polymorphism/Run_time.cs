// 1. Dynamic Polymorphism 
// 2. Runtime Polymorphism 
// 3. Overriding

using System;

// Base Class
public class Animal
{
    // virtual কিওয়ার্ড নির্দেশ করে যে মেথডটি চাইল্ড ক্লাসে পরিবর্তন (override) করা যাবে
    public virtual void MakeSound()
    {
        Console.WriteLine("The animal makes a sound");
    }
}

// Derived Class 1
public class Dog : Animal
{
    // override কিওয়ার্ড ব্যবহার করে মেথডের কাজ পরিবর্তন করা হয়েছে
    public override void MakeSound()
    {
        Console.WriteLine("The dog says: Bow Wow");
    }
}

// Derived Class 2
public class Cat : Animal
{
    public override void MakeSound()
    {
        Console.WriteLine("The cat says: Meow");
    }
}

public class Program
{
    public static void Main()
    {
        Animal myAnimal = new Animal();
        Animal myDog = new Dog(); // Base class reference, Derived class object
        Animal myCat = new Cat();

        myAnimal.MakeSound();
        myDog.MakeSound();   
        myCat.MakeSound();  
    }
}