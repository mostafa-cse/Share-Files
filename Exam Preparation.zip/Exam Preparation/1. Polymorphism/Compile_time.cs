/*
    1. Compile-time Polymorphism 
    2. Static Polymorphism
    3. Method Overloading
*/
public class Animal
{
    public void MakeSound()
    {
        Console.WriteLine("The animal makes a sound");
    }

    public void MakeSound(string sound)
    {
        Console.WriteLine("The animal makes a sound: " + sound);
    }

    public void MakeSound(string sound, int times)
    {
        for (int i = 0; i < times; i++)
        {
            Console.WriteLine(sound);
        }
    }

}

