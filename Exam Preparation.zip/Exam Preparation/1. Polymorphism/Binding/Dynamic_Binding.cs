/*
    1. Dynamic Binding
    2. Late Binding
    3. Runtime Polymorphism
    4. Method Overriding

    Example:
*/

using System;

class Animal
{
    public virtual void MakeSound()
    {
        Console.WriteLine("Animal makes a sound");
    }
}

class Dog : Animal
{
    public override void MakeSound()
    {
        Console.WriteLine("Dog barks");
    }
}

class Cat : Animal
{
    public override void MakeSound()
    {
        Console.WriteLine("Cat meows");
    }
}

class Program
{
    static void Main()
    {
        Animal myAnimal = new Animal();
        Animal myDog = new Dog();
        Animal myCat = new Cat();

        myAnimal.MakeSound(); // Output: Animal makes a sound
        myDog.MakeSound();    // Output: Dog barks
        myCat.MakeSound();    // Output: Cat meows
    }
}