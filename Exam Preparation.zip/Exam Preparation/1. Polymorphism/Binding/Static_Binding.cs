/*
    1. Early Binding
    2. Static Binding

    Method Overloading Example:
*/

using System;

class Calculator
{
    // Method with two integer parameters
    public int Add(int a, int b)
    {
        return a + b;
    }

    // Method with three integer parameters (Overloaded)
    public int Add(int a, int b, int c)
    {
        return a + b + c;
    }

    // Method with two double parameters (Overloaded)
    public double Add(double a, double b)
    {
        return a + b;
    }
}

class Program
{
    static void Main()
    {
        Calculator calc = new Calculator();

        // Calling the first Add method (2 parameters)
        int result1 = calc.Add(5, 10);
        Console.WriteLine("Result 1 (2 integers): " + result1); // Output: 15

        // Calling the second Add method (3 parameters)
        int result2 = calc.Add(5, 10, 15);
        Console.WriteLine("Result 2 (3 integers): " + result2); // Output: 30

        // Calling the third Add method (2 doubles)
        double result3 = calc.Add(5.5, 10.2);
        Console.WriteLine("Result 3 (2 doubles): " + result3); // Output: 15.7
    }
}
